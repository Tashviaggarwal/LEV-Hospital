package com.example.lev

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
